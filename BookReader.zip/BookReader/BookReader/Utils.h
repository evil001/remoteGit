//
//  Utils.h
//  BookReader
//
//  Created by 晓军 唐 on 13-1-11.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#define REQUEST_URL @"http://127.0.0.1:9091/?parmeter="
//图录url
#define CATALOG_URL @"http://new.hosane.com/hosane/upload/catalog/%@"
//拍品url
#define AUCTION_URL @"http://new.hosane.com/hosane/upload/pic%@/%@"

#define IMAGESCAN_PAGE_DATA 10

#define VIEW_CELL_HEIGHT 140

@interface Utils : NSObject

@end
