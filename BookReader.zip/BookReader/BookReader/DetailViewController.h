//
//  DetailViewController.h
//  BookReader
//
//  Created by 晓军 唐 on 13-1-23.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DetailViewController : UIViewController

@end
