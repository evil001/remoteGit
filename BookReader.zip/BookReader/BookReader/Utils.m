//
//  Utils.m
//  BookReader
//
//  Created by 晓军 唐 on 13-1-11.
//  Copyright (c) 2013年 __MyCompanyName__. All rights reserved.
//

#import "Utils.h"

@implementation Utils

@end
