//
//  RequestVO.m
//  IpadLisShow
//
//  Created by Dwen on 13-1-23.
//  Copyright (c) 2013年 Dwen. All rights reserved.
//

#import "RequestVO.h"

@implementation RequestVO
@synthesize className;
@synthesize methodName;
@synthesize specialCode;
@synthesize start;
@synthesize end;
@end
